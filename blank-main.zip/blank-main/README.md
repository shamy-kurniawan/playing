Secrets Name | Uses | Notes
----- | ----- | -----
**LINUX_USERNAME** | For linux system username | Type any name you want
**LINUX_USER_PASSWORD** | For linux shell and root password | Type any password you want
**LINUX_MACHINE_NAME** | For Linux System Computer name | Type any name you want
**NGROK_AUTH_TOKEN** | Token from ngrok | cek you ngrok token
