#!/bin/bash
while :
do
	echo "Press [CTRL+C] to stop.."
	sleep 1
done
